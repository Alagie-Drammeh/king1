# Markdown Preview

1. Install the markdown preview package and view a preview of the `README.md` file. To stop the preview use `CTRL + C`.

    Can you also save the preview into a file?

    - [Markdown Preview](https://www.npmjs.com/package/markdown-preview)

2. Install the markdown pdf package and create a pdf of the `README.md` file.

    Can you also save it as `readme-101.pdf`?

    - [Markdown Pdf](https://www.npmjs.com/package/markdown-pdf)
    
